insert into Login (username,password,roles) values('1001','pass','admin');
insert into Login (username,password,roles) values('1002','pass','admin');
insert into Login (username,password,roles) values('1003','pass','admin');
insert into Login (username,password,roles) values('1004','pass','admin');
insert into Login (username,password,roles) values('1005','pass','admin');
insert into Login (username,password,roles) values('1006','pass','admin');
insert into Login (username,password,roles) values('1007','pass','admin');


