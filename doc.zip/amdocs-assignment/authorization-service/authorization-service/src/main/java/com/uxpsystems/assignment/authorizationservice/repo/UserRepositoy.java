package com.uxpsystems.assignment.authorizationservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.uxpsystems.assignment.authorizationservice.entity.Login;



public interface UserRepositoy extends JpaRepository<Login, String> {

	public Login findByUsername(String login);
	
	

}
