package com.uxpsystems.assignment.authorizationservice.filter;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

@Component
public class ZuulLoggingFilter extends ZuulFilter{

	private Logger logger=LoggerFactory.getLogger(ZuulLoggingFilter.class);
	@Override
	public Object run() throws ZuulException {

		RequestContext context = RequestContext.getCurrentContext();
		HttpServletRequest request = context.getRequest();
		try {
			logger.info("request -> {} then URrequest -> {} I -{}:",IOUtils.toString(request.getReader()),request.getRequestURI());
		} catch (IOException e) {
//			System.out.println("error at request -> {} ");
			e.printStackTrace();
		}
//		System.out.println("logger printed!!!!!!!!!!!!!!!!!!!!");
		/*adding header to the service */
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username=null;
		if (principal instanceof UserDetails) {
		   username = ((UserDetails)principal).getUsername();
		} else {
		   username = principal.toString();
		}

		context.addZuulRequestHeader("username", username);
//		System.out.println("header set :::"+context.getZuulRequestHeaders());
		return null;
	}
	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public int filterOrder() {
		return 1;
	}

	@Override
	public String filterType() {
		return "pre";
	}

}
