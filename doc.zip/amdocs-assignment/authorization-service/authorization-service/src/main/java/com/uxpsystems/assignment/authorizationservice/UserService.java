package com.uxpsystems.assignment.authorizationservice;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.uxpsystems.assignment.authorizationservice.entity.Login;
import com.uxpsystems.assignment.authorizationservice.repo.UserRepositoy;

@Service
public class UserService implements UserDetailsService {
	private final PasswordEncoder passwordEncoder;
	@Autowired
	UserRepositoy userRepositoy;
	 
    public UserService(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }
	
	@Override
	public UserDetails loadUserByUsername(String login) throws UsernameNotFoundException {
//		System.out.println("login UserService:" + login);
		Login loginuser = userRepositoy.findByUsername(login);
//		PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
		if (loginuser!=null) {
//			return new User(login, "password", new ArrayList<>());
		    return new User(login,passwordEncoder.encode(loginuser.getPassword()),this.getGrantedAuthorities(login));

		} else {
			throw new UsernameNotFoundException("User not found with login: " + login);
		}
	}

//	private Collection<GrantedAuthority> getGrantedAuthorities(User user){	
	private Collection<GrantedAuthority> getGrantedAuthorities(String login){

	    Collection<GrantedAuthority> grantedAuthority = new ArrayList<>();
	   /* if(user.getRole().getName().equals("user")){
	        grantedAuthority.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
	    }*/
		Login loginuser = userRepositoy.findByUsername(login);

	    
	    if(loginuser!=null) {
	    	String[] roles=loginuser.getRoles().split(",");
	    	for (String role : roles) {
	    		grantedAuthority.add(new SimpleGrantedAuthority(role));
			}
	    	
	    }
//	    grantedAuthority.add(new SimpleGrantedAuthority("ROLE_USER"));
	    return grantedAuthority;
	}
}