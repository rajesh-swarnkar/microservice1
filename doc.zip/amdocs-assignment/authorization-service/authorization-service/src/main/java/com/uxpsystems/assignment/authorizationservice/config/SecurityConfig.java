package com.uxpsystems.assignment.authorizationservice.config;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uxpsystems.assignment.authorizationservice.UserService;
import com.uxpsystems.assignment.authorizationservice.filter.RequestBodyReaderAuthenticationFilter;

@Component
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	private final UserService userService;
	private final ObjectMapper objectMapper;
	private final PasswordEncoder passwordEncoder;

	

	public SecurityConfig(UserService userService, ObjectMapper objectMapper, PasswordEncoder passwordEncoder) {
		super();
		this.userService = userService;
		this.objectMapper = objectMapper;
		this.passwordEncoder = passwordEncoder;
	}
	

	@Bean
	public DaoAuthenticationProvider authProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(userService);
		authProvider.setPasswordEncoder(passwordEncoder);
		return authProvider;
	}
	
	 @Autowired
	    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
	        auth.authenticationProvider(authProvider());
	    }

	/*@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userService);
	}*/

	@Bean
	public RequestBodyReaderAuthenticationFilter authenticationFilter() throws Exception {
		RequestBodyReaderAuthenticationFilter authenticationFilter = new RequestBodyReaderAuthenticationFilter();
		authenticationFilter.setAuthenticationSuccessHandler(this::loginSuccessHandler);
		authenticationFilter.setAuthenticationFailureHandler(this::loginFailureHandler);
		authenticationFilter.setRequiresAuthenticationRequestMatcher(new AntPathRequestMatcher("/login", "POST"));
		authenticationFilter.setAuthenticationManager(authenticationManagerBean());
		return authenticationFilter;
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {

		http.csrf().disable() // We don't need CSRF for this example
				.authorizeRequests().anyRequest().authenticated() // all request requires a logged in user

//         .and()
//         .formLogin()
//         .loginProcessingUrl("/login") //the URL on which the clients should post the login information
//         .usernameParameter("login") //the username parameter in the queryString, default is 'username'
//         .passwordParameter("password") //the password parameter in the queryString, default is 'password'
//         .successHandler(this::loginSuccessHandler)
//         .failureHandler(this::loginFailureHandler)
				.and().addFilterBefore(authenticationFilter(), UsernamePasswordAuthenticationFilter.class)

				.logout().logoutUrl("/logout") // the URL on which the clients should post if they want to logout
				.logoutSuccessHandler(this::logoutSuccessHandler).invalidateHttpSession(true)

				.and().exceptionHandling() // default respoinse f the client wants to get a resource unauthorized
				.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED));
//		System.out.println("here in config" + http.formLogin().usernameParameter("login").toString());
	}

	private void loginSuccessHandler(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException {
//		System.out.println("came in login Success!!!");
		response.setStatus(HttpStatus.OK.value());
		objectMapper.writeValue(response.getWriter(), "Yayy you logged in!");
	}

	private void loginFailureHandler(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException e) throws IOException {
//		System.out.println("came in loginFailureHandler!!!");
		response.setStatus(HttpStatus.UNAUTHORIZED.value());
		objectMapper.writeValue(response.getWriter(), "Nopity nop!");
	}

	private void logoutSuccessHandler(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException {
//		System.out.println("came in logoutSuccessHandler");
		response.setStatus(HttpStatus.OK.value());
		objectMapper.writeValue(response.getWriter(), "Bye!");
	}

}
