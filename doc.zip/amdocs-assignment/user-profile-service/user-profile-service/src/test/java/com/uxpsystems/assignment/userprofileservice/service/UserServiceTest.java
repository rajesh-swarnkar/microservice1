package com.uxpsystems.assignment.userprofileservice.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import org.junit.Rule;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.uxpsystems.assignment.userprofileservice.entity.UserProfile;
import com.uxpsystems.assignment.userprofileservice.repo.UserRepository;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

	@InjectMocks

	UserServiceImpl userService;

	@Mock
	UserRepository userRepository;

	@Test
	public void saveProfile() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
		UserProfile userprofile = new UserProfile("1001", "ram", "pune", "8542910192", "abc@123.com");
		String username = "1001";
		when(userRepository.save(Mockito.any(UserProfile.class))).thenReturn(userprofile);

		UserProfile profile = new UserProfile("1001", "ram", "pune", "8542910192", "abc@123.com");
		UserProfile responseEntity = userService.saveProfile(username, profile);

		assertThat(responseEntity.equals(profile));
	}

	@Test
	public void updateProfile() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
		UserProfile userprofile = new UserProfile("1001", "ram", "punee", "8542910192", "abc@123.com");
		when(userRepository.save(Mockito.any(UserProfile.class))).thenReturn(userprofile);

		UserProfile profile = new UserProfile("1001", "ram", "punee", "8542910192", "abc@123.com");
		UserProfile responseEntity = userService.saveProfile("1001", profile);

		assertThat(responseEntity.equals(userprofile));
	}

	@Rule
	public ExpectedException expectedException = ExpectedException.none();
	@Test
	public void deleteUserProfile() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
		String responseEntity = userService.deleteUserProfile("1001");

	}

}
