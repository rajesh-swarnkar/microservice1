/*package com.uxpsystems.assignment.userprofileservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserProfileServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/