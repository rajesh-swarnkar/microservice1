package com.uxpsystems.assignment.userprofileservice.controller;


import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.uxpsystems.assignment.userprofileservice.entity.UserProfile;
import com.uxpsystems.assignment.userprofileservice.service.UserService;

 
@ExtendWith(MockitoExtension.class)
//@RunWith(JUnitPlatform.class)
public class UserControllerTest 
{
    @InjectMocks
    UserController userController;
     
    @Mock 	
    UserService userService;
     
    @Test
    public void testCreateProfile() 
    {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
        UserProfile userprofile =  new UserProfile("1001", "ram", "pune", "8542910192", "abc@123.com");
        Optional<String> username=Optional.of("1001");
        when(userService.saveProfile(Mockito.anyString(), Mockito.any(UserProfile.class))).thenReturn(userprofile);

        UserProfile profile = new UserProfile("1001", "ram", "pune", "8542910192", "abc@123.com");
        ResponseEntity<String> responseEntity = userController.createProfile(username, profile);
         
        assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
    }
     
    @Test
    public void updateUserProfile() 
    {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
        String response="user "+"1001"+" updated successfully!!";
        when(userService.updateProfile(Mockito.anyString(), Mockito.any(UserProfile.class))).thenReturn(response);
       
        UserProfile profile = new UserProfile("1001", "ram", "pune", "8542910192", "abc@123.com");
        ResponseEntity<String> responseEntity = userController.updateUserProfile(Optional.of("1001"), profile);
         
        assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
        assertThat(responseEntity.getBody().equalsIgnoreCase(response));
    }
    
    @Test
    public void deleteUserProfile() 
    {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
        String response="deleted successfully!";
        when(userService.deleteUserProfile(Mockito.anyString())).thenReturn(response);

        ResponseEntity<String> responseEntity = userController.deleteUserProfile(Optional.of("1001"));
         
        assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
        assertThat(responseEntity.getBody().equals(response));
        }
   }