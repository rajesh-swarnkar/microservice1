package com.uxpsystems.assignment.userprofileservice.entity;

public class User {

}
