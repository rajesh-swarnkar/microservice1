package com.uxpsystems.assignment.userprofileservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uxpsystems.assignment.userprofileservice.entity.UserProfile;
import com.uxpsystems.assignment.userprofileservice.service.UserService;

@RestController
@RequestMapping("/profile")
public class UserController {
	@Autowired
	UserService userService;
	
	@GetMapping("")
	public ResponseEntity<UserProfile> getUsers(@RequestHeader(name="username", required = false) Optional< String> userName) {
//		System.out.println("username::::::::"+userName.orElseGet(null));
		UserProfile profile=userService.getUser(userName.orElseGet(null));
		ResponseEntity<UserProfile> response=new ResponseEntity<>(profile, HttpStatus.OK);
		return response;
	}
	
	
	@PostMapping("")
	public ResponseEntity<String> createProfile(@RequestHeader(name="username", required = false) Optional< String> userName,
			@RequestBody UserProfile profile) {
		UserProfile userProfile=userService.saveProfile(userName.orElse(null),profile);
		ResponseEntity<String> response=new ResponseEntity<>("Profile for "+userProfile.toString() +" has been created", HttpStatus.OK);;
				
		return response;
		
	}
	@PutMapping("")
	public ResponseEntity<String> updateUserProfile(@RequestHeader(name="username", required = false) Optional< String> userName,
			@RequestBody UserProfile profile) {
			String userResponse=userService.updateProfile(userName.orElse(null),profile);
			ResponseEntity<String> response= new ResponseEntity<>(userResponse, HttpStatus.OK);
			return response;
	}
	
	@DeleteMapping("")
	public ResponseEntity<String> deleteUserProfile(@RequestHeader(name="username", required = false) Optional< String> userName){
		String msg=null;
		try {
			msg = userService.deleteUserProfile(userName.orElse(""));
		}catch (Exception e) {
//			System.out.println(e.getMessage());
			e.printStackTrace();
			msg="No User Profile Found to delete !!!";
		}
		
		
		return new ResponseEntity<String>(msg, HttpStatus.OK);	
	}
	
	}
	


