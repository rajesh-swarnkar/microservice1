/**
 * 
 */
package com.uxpsystems.assignment.userprofileservice.service;

import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.support.SecurityContextProvider;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.uxpsystems.assignment.userprofileservice.entity.UserProfile;
import com.uxpsystems.assignment.userprofileservice.repo.UserRepository;
@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepository userRepo;
	@Override
	public UserProfile getUser(String userName) {
		
		Optional<UserProfile> profile =this.userRepo.findById(userName);
		if(profile.isPresent()) {
			 return profile.get();
		} else {
//			System.out.println(userName+" user Profile not found!!");
			return new UserProfile();
		}
		
	}
	@Override
	public UserProfile saveProfile(String userName,UserProfile profile) {
		UserProfile user=null;
		try {
			 user= userRepo.findById(userName).get();
		}catch(Exception e) {
//			System.out.println(e.getMessage());
			user = new UserProfile();
			user.setUserId(userName);
			user.setEmail(profile.getEmail()!=null?profile.getEmail():null);
			user.setAddress(profile.getAddress()!=null?profile.getAddress():null);
			user.setName(profile.getName()!=null?profile.getName():null);
			user.setPhoneNumber(profile.getPhoneNumber()!=null?profile.getPhoneNumber():null);
			userRepo.save(user);
		}
		return user;
	}
	@Override
	public String updateProfile(String username, UserProfile profile) {
		UserProfile user= null;
		try {
			 user= userRepo.findById(username).get();
		}catch(Exception e) {
//			System.out.println(e.getMessage());
			return "User Profile does'nt exists!";
		}
		
		if(user!=null) {
			user.setEmail(profile.getEmail()!=null?profile.getEmail():null);
			user.setAddress(profile.getAddress()!=null?profile.getAddress():null);
			user.setName(profile.getName()!=null?profile.getName():null);
			user.setPhoneNumber(profile.getPhoneNumber()!=null?profile.getPhoneNumber():null);
			userRepo.save(user);
			return "Profile for user "+username+" updated successfully!!";
		}
		else {
			return "user can't update other's profile!";
		}
		
		
	}
	@Override
	public String deleteUserProfile(String username) {
		String response;
		try{
			this.userRepo.deleteById(username);
			response="profile for user "+username+" deleted successfully!";
		}catch(IllegalArgumentException e) {
//			System.out.println("username is null");
			response = "can't delete , user profile not found!";
		}
		return response;
	}

}
