package com.uxpsystems.assignment.userprofileservice.service;

import java.util.Optional;

import com.uxpsystems.assignment.userprofileservice.entity.UserProfile;

public interface UserService {

	public UserProfile getUser(String userName);

	public UserProfile saveProfile(String userName, UserProfile profile);

	public String updateProfile(String username, UserProfile profile);

	public String deleteUserProfile(String username);

}
