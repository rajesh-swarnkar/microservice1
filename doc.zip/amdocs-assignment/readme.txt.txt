This document will guide you use this app..
1. Please run user-profile-service first and then run Authorization service.
2. Please use http://localhost:8765/ as a base url.
	e.g.- http://localhost:8765/login for login
		  http://localhost:8765/logout for logout
		  http://localhost:8765/profile for all user profile related operation.
3. For smooth access, please find attached images and access it label wise.

	   